﻿using System;
using Users;
using Ideas;
using Menu;

namespace kursovaya_1kurs
{
    class Program
    {
        static void Main()
        {
            Console.CursorVisible = false;
            Menuu.MainMenu();
        }
    }
}
